const canvas = document.querySelector('#c');


import * as THREE from './node_modules/three/src/Three.js';

const scene = new THREE.Scene();
const loader = new THREE.TextureLoader();

var camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 1, 10000);

var renderer = new THREE.WebGLRenderer( {canvas,  alpha: true } );
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

var geometry = new THREE.BoxGeometry(700, 700, 700, 10, 10, 10);

const material = new THREE.MeshBasicMaterial({
    map: loader.load('shrek.jfif'),
  });


//var material = new THREE.MeshBasicMaterial({color: 0xfffff, wireframe: true});
var cube = new THREE.Mesh(geometry, material);
scene.add(cube);
camera.position.z = 1000;
function playSound(url) {
    const audio = new Audio(url);
    
    
    audio.play();
  }

window.addEventListener( 'resize', onWindowResize, false );

function onWindowResize(){
    
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize( window.innerWidth, window.innerHeight );

}

function render() {
    // playSound("https://www.youtube.com/watch?v=7l8eQIErPvM&")
    requestAnimationFrame(render);
    renderer.render(scene, camera);
    cube.rotateX(.001)
    cube.rotateZ(.00001)
    cube.rotateY(.001)
    
    
    
    
}

function start(){
    var elem = document.getElementById('s');
    elem.parentNode.removeChild(elem);
    playSound("j.mp3")
    render();
}
document.getElementById("s").addEventListener("click", start);



